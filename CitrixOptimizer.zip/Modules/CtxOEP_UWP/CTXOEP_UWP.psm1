﻿If (-not $(Get-Module -ListAvailable -Name Appx)) {
    Write-Host "Universal Windows Applications are not available on this system" 
    Return
}

# Get-AppxProvisionedPackage is quite slow. Instead of constantly running it, we are using cache to store the current packages in memory. Cache can be invalidated by changing the value of CTXOEUWP_IsCacheValid to false, in which case it will be automatically reloaded. 
$CTXOEUWP_Cache = Get-AppxProvisionedPackage -online
$CTXOEUWP_IsCacheValid = $true;

# In Windows 10 build 1709, new argument has been added (-AllUsers). This check determines if this argument is supported by current operating system or not. 
$CTXOEUWP_AllUsersSupported = $(Get-Command Remove-AppxProvisionedPackage -ParameterName AllUsers -ErrorAction SilentlyContinue) -is [System.Management.Automation.CmdletInfo];
Write-Host "Removal of already provisioned applications supported: $CTXOEUWP_AllUsersSupported"

Function Get-CTXOEUWPApp {
    If ($CTXOEUWP_IsCacheValid -eq $false) {
        $CTXOEUWP_Cache = Get-AppxProvisionedPackage -online
    }

    Return $CTXOEUWP_Cache
}

Function Test-CTXOEUWPAppExist ([String]$Name) {
    Return $(Get-CTXOEUWPApp | Where-Object {$_.DisplayName -eq $Name}) -is [Microsoft.Dism.Commands.AppxPackageObject]
}

Function Invoke-CTXOEUWPExecute ([Xml.XmlElement]$Params) {
    [Boolean]$m_Exists = Test-CTXOEUWPAppExist -Name $Params.Name

    If (-not $m_Exists) {
        $Global:CTXOE_Result = $True
        $Global:CTXOE_Details = "UWP app is not installed"
        Return
    }

    $m_PackageFullName = Get-AppxProvisionedPackage -online | Where-Object {$_.DisplayName -eq $Params.Name} | Select-Object -ExpandProperty PackageName

    Try {
        If ($CTXOEUWP_AllUsersSupported) {
            Remove-AppxProvisionedPackage -PackageName $m_PackageFullName -Online -AllUsers | Out-Null
        } Else {
            Remove-AppxProvisionedPackage -PackageName $m_PackageFullName -Online | Out-Null
        }
    } Catch {
        $Global:CTXOE_Details = "Failed to remove UWP app with following error: $($_.Exception.Message)"; 
    }

    $CTXOEUWP_IsCacheValid = $false; 
    $Global:CTXOE_SystemChanged = $true;

    [Boolean]$m_Exists = Test-CTXOEUWPAppExist -Name $Params.Name

    $Global:CTXOE_Result = $m_Exists - 1

    If (-not $m_Exists) {
        $Global:CTXOE_Details = "UWP app has been removed"; 
    }

    Return
}

Function Invoke-CTXOEUWPAnalyze ([Xml.XmlElement]$Params) {
    [Boolean]$m_Exists = Test-CTXOEUWPAppExist -Name $Params.Name

    [Boolean]$Global:CTXOE_Result = $m_Exists - 1
    If ($m_Exists) {
        $Global:CTXOE_Details = "UWP app is installed"
    } Else {
        $Global:CTXOE_Details = "UWP app is not installed"
    }

    Return
}

Function Invoke-CTXOEUWPRollback ([Xml.XmlElement]$Params) {
    $Global:CTXOE_Result = $False
    $Global:CTXOE_Details = "UWP module does NOT support rollback. If you need to rollback the changes, re-install the application manually"
}
# SIG # Begin signature block
# MIIa/AYJKoZIhvcNAQcCoIIa7TCCGukCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUes1iLix3920tzmaMH0YCqfFd
# Fp+gghTwMIIFJDCCBAygAwIBAgIQCpJdJFWANibhh6AFcJolkDANBgkqhkiG9w0B
# AQsFADByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFz
# c3VyZWQgSUQgVGltZXN0YW1waW5nIENBMB4XDTE4MDgwMTAwMDAwMFoXDTIzMDkw
# MTAwMDAwMFowYDELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFENpdHJpeCBTeXN0ZW1z
# LCBJbmMuMQ0wCwYDVQQLEwRHTElTMSMwIQYDVQQDExpDaXRyaXggVGltZXN0YW1w
# IFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANjWtJ4e
# cpVfB34YnxfYNvb1Rp2JbBu5/G9Boe8aEBQc2zidW82ousZrXj2QD2qUA1Ee8noo
# t1KGcQdY0WzzbSIU7KHePB5KaESWjtHVJ3BW6W9q+U24m2dPD/oaNxGx6DtD7M0N
# lMBIRZKo7aNIsRIlHkg7wnNQzqi0jTkzBO7S34holaqhfuQgqkgKqGmcoSIXVqNm
# EFaU+5kpYFqpMo6x1sSAgfgNEcIgGjnj8xzdU1rnh6iNYMxOt8guMWk2z+KKNbux
# H6YLAA9VBYW417Zf153/5L4ejuxxUhCp03JkoUIWjSRjz3m24HD9K8NSgJ0AdDpN
# E8ZPmIJCMFi9FYcCAwEAAaOCAcYwggHCMB8GA1UdIwQYMBaAFPS24SAd/imu0uRh
# pbKiJbLIFzVuMB0GA1UdDgQWBBS1Y37AhXUHPaYuvS/SUsWFFisSbTAMBgNVHRMB
# Af8EAjAAMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDBP
# BgNVHSAESDBGMDcGCWCGSAGG/WwHATAqMCgGCCsGAQUFBwIBFhxodHRwczovL3d3
# dy5kaWdpY2VydC5jb20vQ1BTMAsGCWCGSAGG/WwDFTBxBgNVHR8EajBoMDKgMKAu
# hixodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVkLXRzLmNybDAy
# oDCgLoYsaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC10cy5j
# cmwwgYUGCCsGAQUFBwEBBHkwdzAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tME8GCCsGAQUFBzAChkNodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRTSEEyQXNzdXJlZElEVGltZXN0YW1waW5nQ0EuY3J0MA0GCSqG
# SIb3DQEBCwUAA4IBAQBrQ4tHgdu37madmYML6Ikfb8bNWoritioGcrlVfsMEGdLN
# LAsPYqrMo9mZmNzKTE7UVzGVdwb+Cfz9IRfD6hmK6hhEuom+XNzC8LGQ3o7U2ede
# YF/xuIcFZAwmQnXOoVl4yDWKrfyalOIO9wpQ6bDV7f0CPa8j3Qj2eNJ2u2qKnRE+
# x5Iz8j5lsjQeefIriGVHd27R93ai0li9WZMT9KKOAk06R0Z0qyG70jXhoUp4Or5c
# lv5mmVJgmxr1hMjVg7v95WGY50p2+cfhqLlViu2cu0LCg31IUb0lbTYNbgY1eca2
# cr8F0ppVnrt55YVfb1M80huj9DeYYjeFSKkcN+6xMIIFMDCCBBigAwIBAgIQBAkY
# G1/Vu2Z1U0O1b5VQCDANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMG
# A1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQw
# IgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMTMxMDIyMTIw
# MDAwWhcNMjgxMDIyMTIwMDAwWjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhE
# aWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ29kZSBTaWduaW5nIENBMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+NOzHH8OEa9ndwfTCzFJGc/Q+0WZsTrb
# RPV/5aid2zLXcep2nQUut4/6kkPApfmJ1DcZ17aq8JyGpdglrA55KDp+6dFn08b7
# KSfH03sjlOSRI5aQd4L5oYQjZhJUM1B0sSgmuyRpwsJS8hRniolF1C2ho+mILCCV
# rhxKhwjfDPXiTWAYvqrEsq5wMWYzcT6scKKrzn/pfMuSoeU7MRzP6vIK5Fe7SrXp
# dOYr/mzLfnQ5Ng2Q7+S1TqSp6moKq4TzrGdOtcT3jNEgJSPrCGQ+UpbB8g8S9MWO
# D8Gi6CxR93O8vYWxYoNzQYIH5DiLanMg0A9kczyen6Yzqf0Z3yWT0QIDAQABo4IB
# zTCCAckwEgYDVR0TAQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0l
# BAwwCgYIKwYBBQUHAwMweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRw
# Oi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRz
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwgYEGA1Ud
# HwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFz
# c3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwTwYDVR0gBEgwRjA4BgpghkgB
# hv1sAAIEMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9D
# UFMwCgYIYIZIAYb9bAMwHQYDVR0OBBYEFFrEuXsqCqOl6nEDwGD5LfZldQ5YMB8G
# A1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMA0GCSqGSIb3DQEBCwUAA4IB
# AQA+7A1aJLPzItEVyCx8JSl2qB1dHC06GsTvMGHXfgtg/cM9D8Svi/3vKt8gVTew
# 4fbRknUPUbRupY5a4l4kgU4QpO4/cY5jDhNLrddfRHnzNhQGivecRk5c/5CxGwcO
# kRX7uq+1UcKNJK4kxscnKqEpKBo6cSgCPC6Ro8AlEeKcFEehemhor5unXCBc2XGx
# DI+7qPjFEmifz0DLQESlE/DmZAwlCEIysjaKJAL+L3J+HNdJRZboWR3p+nRka7Lr
# ZkPas7CM1ekN3fYBIM6ZMWM9CBoYs4GbT8aTEAb8B4H6i9r5gkn3Ym6hU/oSlBiF
# LpKR6mhsRDKyZqHnGKSaZFHvMIIFMTCCBBmgAwIBAgIQCqEl1tYyG35B5AXaNpfC
# FTANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNl
# cnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdp
# Q2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMTYwMTA3MTIwMDAwWhcNMzEwMTA3
# MTIwMDAwWjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEy
# IEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEAvdAy7kvNj3/dqbqCmcU5VChXtiNKxA4HRTNREH3Q+X1NaH7n
# tqD0jbOI5Je/YyGQmL8TvFfTw+F+CNZqFAA49y4eO+7MpvYyWf5fZT/gm+vjRkcG
# GlV+Cyd+wKL1oODeIj8O/36V+/OjuiI+GKwR5PCZA207hXwJ0+5dyJoLVOOoCXFr
# 4M8iEA91z3FyTgqt30A6XLdR4aF5FMZNJCMwXbzsPGBqrC8HzP3w6kfZiFBe/WZu
# VmEnKYmEUeaC50ZQ/ZQqLKfkdT66mA+Ef58xFNat1fJky3seBdCEGXIX8RcG7z3N
# 1k3vBkL9olMqT4UdxB08r8/arBD13ays6Vb/kwIDAQABo4IBzjCCAcowHQYDVR0O
# BBYEFPS24SAd/imu0uRhpbKiJbLIFzVuMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1R
# i6enIZ3zbcgPMBIGA1UdEwEB/wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMIMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGB
# BgNVHR8EejB4MDqgOKA2hjRodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNl
# cnRBc3N1cmVkSURSb290Q0EuY3JsMDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMFAGA1UdIARJMEcwOAYK
# YIZIAYb9bAACBDAqMCgGCCsGAQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5j
# b20vQ1BTMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAQEAcZUS6VGHVmnN
# 793afKpjerN4zwY3QITvS4S/ys8DAv3Fp8MOIEIsr3fzKx8MIVoqtwU0HWqumfgn
# oma/Capg33akOpMP+LLR2HwZYuhegiUexLoceywh4tZbLBQ1QwRostt1AuByx5jW
# PGTlH0gQGF+JOGFNYkYkh2OMkVIsrymJ5Xgf1gsUpYDXEkdws3XVk4WTfraSZ/tT
# YYmo9WuWwPRYaQ18yAGxuSh1t5ljhSKMYcp5lH5Z/IwP42+1ASa2bKXuh1Eh5Fhg
# m7oMLSttosR+u8QlK0cCCHxJrhO24XxCQijGGFbPQTS2Zl22dHv1VjMiLyI2skui
# SpXY9aaOUjCCBVswggRDoAMCAQICEAnDseogl67R4kPZAkwTwVowDQYJKoZIhvcN
# AQELBQAwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBB
# c3N1cmVkIElEIENvZGUgU2lnbmluZyBDQTAeFw0yMDA2MTgwMDAwMDBaFw0yMTA2
# MjMxMjAwMDBaMIGXMQswCQYDVQQGEwJVUzEQMA4GA1UECBMHRmxvcmlkYTEYMBYG
# A1UEBxMPRm9ydCBMYXVkZXJkYWxlMR0wGwYDVQQKExRDaXRyaXggU3lzdGVtcywg
# SW5jLjEeMBwGA1UECxMVWGVuQXBwKFNlcnZlciBTSEEyNTYpMR0wGwYDVQQDExRD
# aXRyaXggU3lzdGVtcywgSW5jLjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKz/6enTDjtRARofX6CxBvXTSrNSToniGVJQq0tJmtGIjuf5CKHWaGei1OGe
# kftP8Pj4Y5bGzW3sT6GwQ894B0niwu/nnqdh6VDbMWfy8eZADi4x0qYvVD7Wxmq/
# p+qAn58iRG2ikLViEUskmc2Ysa9cD8s11gCR3rLWm55zllxBbg756aJVrSRKpIcf
# Tcxm6hECowr983Np/XhVRASj47DWjBrYMeXQrtE370RhcHRStHhKhPhzcGfDKoxQ
# sT8jibnS/WYoUjO7XRsUkuQdUfgWI6FMuvfZ368mVk7SaOJx1F2LF9wec2j5dvoi
# ynLT6HGS0AhiqkiWEPLBfK1JgIUCAwEAAaOCAcUwggHBMB8GA1UdIwQYMBaAFFrE
# uXsqCqOl6nEDwGD5LfZldQ5YMB0GA1UdDgQWBBS8TYAcxKWVVRP7XZD6m2dVIFa4
# +zAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwdwYDVR0fBHAw
# bjA1oDOgMYYvaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC1j
# cy1nMS5jcmwwNaAzoDGGL2h0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9zaGEyLWFz
# c3VyZWQtY3MtZzEuY3JsMEwGA1UdIARFMEMwNwYJYIZIAYb9bAMBMCowKAYIKwYB
# BQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCAYGZ4EMAQQBMIGE
# BggrBgEFBQcBAQR4MHYwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0
# LmNvbTBOBggrBgEFBQcwAoZCaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0U0hBMkFzc3VyZWRJRENvZGVTaWduaW5nQ0EuY3J0MAwGA1UdEwEB/wQC
# MAAwDQYJKoZIhvcNAQELBQADggEBAFyJ77tCmlj1AP+NVBvr23SJfIIcp5of8Z/4
# LcYV7b2exZxLbpzrqCVUpnYW/eg4aXI1Xz3cFXWeejPaif+ZdTA2Nv8AChDuXvTF
# MUpUyNDRyv74zM267r3I8KPq+fz8kcsEncRElqRMA2HrlCJO0hG/wSMOSZHsrcEv
# DWRDmuIDnvxXXvrR+f2rq97u8Pd/iK3GKL6whMMQyXxIaQnucIezUqCZqbhggxhg
# wVkDxsYimV9IsycT4D/4WIO2J71y1ZglyUFkVMr420UpU9sdkgQixREhOJKiC0hi
# rPEZBLxqnnFUCpAzzYQTdeZc4aOixwOTgvYQn1Br+Yd5tzB5JEcxggV2MIIFcgIB
# ATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFz
# c3VyZWQgSUQgQ29kZSBTaWduaW5nIENBAhAJw7HqIJeu0eJD2QJME8FaMAkGBSsO
# AwIaBQCggcQwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFAqUWhwpe4WaG8gYnlTg
# ivwZKSH1MGQGCisGAQQBgjcCAQwxVjBUoDiANgBDAGkAdAByAGkAeAAgAFMAdQBw
# AHAAbwByAHQAYQBiAGkAbABpAHQAeQAgAFQAbwBvAGwAc6EYgBZodHRwOi8vd3d3
# LmNpdHJpeC5jb20gMA0GCSqGSIb3DQEBAQUABIIBAKlykmF1y7YqSO6S8UEKk8tW
# l+JoeQ3Nr8AfBI+UuoNTqbMrkcLG9EeuKzr59sA84WpWXlmSQLEwUzeKKgR7HVaV
# XAxNuE6VXgyLSYbtyMrCi7z3EzjkIv+57zoVCk174nebiqBRrcJLgYiMrxxsZTlA
# 6aeD5IiI3Xm35o0v5WEbzIykhjva+iS3Q07COdkadtbxwfDg8miS5lMbvfeugWe4
# P8css6Fpak586gMys6IcRWrEz68CgdQPCA5rjD2fjCpTEMzVMbDKduna8P3NksLU
# b/wR1bxpsR5ZZLpKCph/89R/6nEw9wTXXQRu4Tj8mE6aMsGdRmZhwA5AVDeApXKh
# ggL9MIIC+QYJKoZIhvcNAQkGMYIC6jCCAuYCAQEwgYYwcjELMAkGA1UEBhMCVVMx
# FTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
# bTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIFRpbWVzdGFtcGlu
# ZyBDQQIQCpJdJFWANibhh6AFcJolkDANBglghkgBZQMEAgEFAKCCATQwGAYJKoZI
# hvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjAxMjAxMDQ1NDA3
# WjAvBgkqhkiG9w0BCQQxIgQgXR/wUJuHSWtqxsHkZKk9+rIHQH220X4Tzcoo8+0q
# BpcwgcgGCyqGSIb3DQEJEAIvMYG4MIG1MIGyMIGvBCCwKs7bobLXZazW6cUGelYb
# 0VThhTIMHM9eYya2pW8uozCBijB2pHQwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoT
# DERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UE
# AxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIFRpbWVzdGFtcGluZyBDQQIQCpJd
# JFWANibhh6AFcJolkDANBgkqhkiG9w0BAQEFAASCAQC91CyuKTV9DLEGWE7mrKYw
# gzNUEy88adIKGnVR/ARuQhaWSR/NELGUggcc5RMTpx5q7FactTQeP0q70Bd7Fiyn
# 3BGb5j5En+z8qd5RIjSww6RR07yRq/fyaAkRQkTB8/5U4Wjj+SsP3B9Jry6Lksyh
# mb5PH0Qt9RYCLoEeUkUhQweeUy9rt6hdDZuOauf0u7njYlL+Ex3NSKbUllrXMvsq
# Pa/vO90XKGgqNE/nzXzeSufIhq0Ri5WRaQR6HN9SfoJQ/ruM0k34ryw3H3BAlnOa
# O3r3A2bgwB21Ae1zCEMoN3vV240MNOrOu7jqJdADVQ0PqrJFeW0q5yMmZ0gAeWbS
# SIG # End signature block
